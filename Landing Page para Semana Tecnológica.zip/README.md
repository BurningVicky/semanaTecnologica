
  # Landing Page para Semana Tecnológica

  This is a code bundle for Landing Page para Semana Tecnológica. The original project is available at https://www.figma.com/design/kjy7D1cLuQNfJglzzn8iAX/Landing-Page-para-Semana-Tecnol%C3%B3gica.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  